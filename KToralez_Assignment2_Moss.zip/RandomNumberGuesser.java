/*
 * 	Class: CMSC203 CRN 32295
 	Program: Assignment # 2
 	Instructor: Professor Tarek
 	Summary of Description: This is a guessing game for the user. Basically, the user keeps guessing a number between 0-100 until they guess the right number, 
 	displaying how many times they tried in total. It also tells them a new range every time and how high or how low their previous guess was. 
 	Due Date: 2/16/2021
 	Integrity Pledge: I pledge that I have completed the programming assignment independently.
 	I have not copied the code from a student or any source.
	Student�s Name: Kevin Toralez

 */
import java.util.Scanner;

/* This is a class that holds the workings of a random number guesser game. It consists of user scanning input, a randomly generated value at the beginning of the program, an input validation message telling the user
 * the range for the next guessed value, and a way for the user to play again if they wanted to. 
 */
public class RandomNumberGuesser {
	//Commented Name of the Programmer:Kevin Toralez
	
	/* This main method is meant to call the Repeat() method which contains all the code for the random number guesser game. It is called repeat because it can also be used to again make the game function from the very 
	*  beginning. The calling of this function not only initiates the game but also makes it reassured that every time the program restarts that the user will be able to play again. 
	*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Repeat();

}
	/* The Repeat() method consists of code that first asks the user to guess a number between 0-100, taking in their user input through scanning after generating the randomly generated value. Then, the values 0, 100, and
	 *  the value guessed by the user are used for another method that is stored in an object from the RNG.java methods to notify the user the range of the values their guess is in and whether their guess was too high or
	 *  too low. Thereafter, a while loop is used to perform the same actions, which only repeats if the value user entered is y,however differently than before, this time the value the user guessed previously is known 
	 *  so that is used for the new input validation. This process continues until the user guesses the right number, where they are told Congrats and they are given the option to play again. If at any time the
	 *  user inputs a value that isn't suitable, for example, -1 or 1009 or they dont enter the right values, either y or n, when asked to play again, they will be continually be asked the same question until they
	 *  enter the right value in the range provided to them. Additionally, the PlayAgainInvalid() method is called if the instance mentioned before, y or n isn't entered, occurs. 
	 *  
	 */
	public static void Repeat()
	{
		int result;
		int random;
		 int high;
		 int low;
		 int count=0;
		 
		System.out.println("Please enter a value between 0-100 to guess(integers)");
		Scanner kb = new Scanner(System.in);
		RNG randomGuesser = new RNG();	// Access to RNG.java is created
		
		random = randomGuesser.rand(); // Random number is created
		
		System.out.println("Random number produced: "+random);
	
		result = kb.nextInt();
		
		if(result<=0 || result>=100) //In the case that the user enters a value 0,100, or below or above these values
		{
			System.out.println("Please try again by entering a value between 0-100, not including these values or above or below.\n");
			Repeat();
		}
		if(result>random) //If the value is too high then the user is notified and the guessed increments by 1
		{
			System.out.println("Your guess is too high!");
			System.out.println("The number of guesses taken so far: " + ++count);
			high=result;
			low=0;
		}
		else if(result==random) //If they guess correctly the first time the user is told they guessed right and that they took that many guesses.
		{
			System.out.println("Your guess matches the random number!");
			System.out.println("The number of guesses taken: " + ++count);
			high=result;
			low=0;
		}
		else //If the value is too high then the user is notified and the guessed increments by 1
		{	System.out.println("Your guess is too low!");
			System.out.println("The number of guesses taken so far: " + ++count);
			low=result;
			high=100;
		}
		if(random!=result) //If they guessed incorrectly the first time, those values that were set in the if else structure are used as arguments in the inputvalidation method.
			randomGuesser.inputValidation(result,low,high);
		else	//If they do guess correctly, they are asked to play again. Depending on what they put, "y", "n", or something else, an output occurs. 
		{	
			System.out.println("Congrats you did it! Do you want to play again? ( y or n)");
			String continuePlaying = kb.next();
			kb.nextLine();
			if(continuePlaying.equalsIgnoreCase("y")) //counter is reset and the Repeat() method is called to restart the game.
			{	
				randomGuesser.resetCount();
				Repeat();
			}
			else if(continuePlaying.equalsIgnoreCase("n"))	//Program ends
			{
				System.out.println("Program Terminated.");
				System.out.println("Kevin Toralez");
				System.exit(0);
			}
			else //PlayAgainInvalid is invoked if the user enters a value that is not y or n
			{
		
				PlayAgainInvalid();
			
			}
		}
		
		// This part of the program occurs if the user doesn't get the number the right the first time 
		do {	
			result = kb.nextInt();
			if(result>random)	//User is told their guess is too high, the counter increments, and the last guess is used as the high variable
			{	
				System.out.println("Your guess is too high!");
				System.out.println("The number of guesses taken so far: " + ++count);
				high=result;
			
			}
			else if(result<random) //User is told their guess is too low, the counter increments, and the last guess is used as the low variable
			{
				System.out.println("Your guess is too low!");
				System.out.println("The number of guesses taken so far: " + ++count);
				low=result;
		
			}
			else //If none of the above is true, then that means they did guess correctly and the amount of guesses they took is displayed, they are asked if they wanna play again, and while loop ends
			{	
				System.out.println("Your guess matches the random number!");
				System.out.println("The number of guesses taken: " + ++count);
				System.out.println("Congrats you did it! Do you want to play again? ( y or n)");
				String continuePlaying = kb.next();
				kb.nextLine();
				if(continuePlaying.equalsIgnoreCase("y"))
				{
					Repeat();
				}
				else if(continuePlaying.equalsIgnoreCase("n"))
				{
					System.out.println("Program Terminated.");
					System.out.println("Kevin Toralez");
					System.exit(0);
				}
			
				else
				{
					PlayAgainInvalid();
				}
			}
			randomGuesser.inputValidation(result,low,high);
		} 	while(!(random==result));
		}
	
	/* PlayAgainInvalid() is meant to account for the case if the user somehow puts something other than 'y' or 'n', for example "yes" or "no" or "No i dont want to." If they press "y" the Repeat() method is called, if they 
	 * press "n" then the program is terminated, if they press anything else, recursion occurs calling the PlayAgainInvalid() method. 
	 */
		public static void PlayAgainInvalid()
		{
			Scanner kb = new Scanner(System.in);
			System.out.println("Invalid input... Please try again by inputting either \"y\" or \"n\"");
			System.out.println("Your guess matches the random number!");
			System.out.println("Congrats you did it! Do you want to play again? ( y or n)");
			String continuePlaying = kb.next();
			kb.nextLine();
			if(continuePlaying.equalsIgnoreCase("y")) //Repeat() method is called and program restarts
			{
				Repeat();
			}
			else if(continuePlaying.equalsIgnoreCase("n"))	//Program terminates 
			{
				System.out.println("Program Terminated.");
				System.out.println("Kevin Toralez");
				System.exit(0);
			}
			else	//Recursion occurs and this same method repeats
			{
				PlayAgainInvalid();
			}
		
		}
}

	
