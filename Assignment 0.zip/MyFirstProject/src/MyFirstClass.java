
public class MyFirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("This is my first program!");
	}

}
